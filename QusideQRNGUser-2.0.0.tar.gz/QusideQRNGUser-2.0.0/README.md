To install this library follow these steps:
- Copy libqusideQRNGuser.so to /usr/lib
- Copy quside_QRNG_user.h to /usr/include
- Copy quside.conf to /etc/ld.so.conf
